
class MonteCarloAlgorithm:
    def choose_action(self, observation):
        pass                

    def learn(self, s, a, r, s_):
        pass
    
    def update(self):
        pass